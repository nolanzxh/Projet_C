/*#include<iostream>
#include "QuatreTree.h"
using namespace std;

template <class ele>
QuatreTreeNode<ele>::QuatreTreeNode() {

	Child1 = Child2= Child3 = Child4 = NULL;

}

template <class ele>
QuatreTreeNode<ele>::QuatreTreeNode(const ele &d,
	QuatreTreeNode<ele> *lChild1 ,
	QuatreTreeNode<ele> *lChild2 ,
	QuatreTreeNode<ele> *lChild3 ,
	QuatreTreeNode<ele> *lChild4 ) {

	date = d;
	Child1 = lChild1;
	Child2 = lChild2;
	Child3 = lChild3;
	Child4 = lChild4;
}


template<class ele>
void QuatreTree<ele>::InsertChild1(QuatreTreeNode<ele> *p, const ele& e) {//����p�ĵ�һ���ӣ�ֵΪe

	if (p == NULL)
		return;
	else {
		QuatreTreeNode<ele> *child = new QuatreTreeNode<ele>(e);
		if (p->Child1 != NULL)
			child->Child1 = p->Child1;
		p->Child1 = child;
		return;
	}

}

template<class ele>
void QuatreTree<ele>::InsertChild2(QuatreTreeNode<ele> *p, const ele& e) {

	if (p == NULL)
		return;
	else {
		QuatreTreeNode<ele> *child = new QuatreTreeNode<ele>(e);
		if (p->Child2 != NULL)
			child->Child2 = p->Child2;
		p->Child2 = child;
		return;
	}

}

template<class ele>
void QuatreTree<ele>::InsertChild3(QuatreTreeNode<ele> *p, const ele& e) {

	if (p == NULL)
		return;
	else {
		QuatreTreeNode<ele> *child = new QuatreTreeNode<ele>(e);
		if (p->Child3 != NULL)
			child->Child3 = p->Child3;
		p->Child3 = child;
		return;
	}

}

template<class ele>
void QuatreTree<ele>::InsertChild4(QuatreTreeNode<ele> *p, const ele& e) {

	if (p == NULL)
		return;
	else {
		QuatreTreeNode<ele> *child = new QuatreTreeNode<ele>(e);
		if (p->Child4 != NULL)
			child->Child4 = p->Child4;
		p->Child4 = child;
		return;
	}

}


template<class ele>
QuatreTree<ele>::~QuatreTree() {

	delete []root;

}


template<class ele>
QuatreTree<ele>::QuatreTree() {

	n = 0;
	root = NULL;

}


template<class ele>
void QuatreTree<ele>::PreOrder() const {

	PreOrder(root);

}

template<class ele>
void QuatreTree<ele>::PreOrder(QuatreTreeNode<ele> *r)const {
	if (r != NULL){
		cout << r->date;
	PreOrder(r->Child1);
	PreOrder(r->Child2);
	PreOrder(r->Child3);
	PreOrder(r->Child4);
}
}

template<class ele>
void QuatreTree<ele>::SetArr() {
	cout << "\nentrer le graphe";
	for (int i = 1; i <= n; i++)
		for (int j = =1; j <= n; j++)
			cin >> arr[i][j];

}

template<class ele>
int QuatreTree<ele>::ok(const int a, const int b, const int c, const int d) const{

	bool black = 0;
	bool white = 0;
	for (int i = a; i < b; i++)
		for (int j = c; j < d; j++)
		{
			if (arr[i][j] == 1) white = 1; //1�Ǻ�ɫ
			if (arr[i][j] == 0) black = 1;//0�ǰ�ɫ
		}
	if (white && black) return 0;//�к��а�
	else if (white && (!black)) return 1;//����
	else if ((!white) && black) return 2;//����
}


template<class ele>
void QuatreTree<ele>::BuildTree( int a,  int b,  int c, int d, QuatreTreeNode<ele> *r) //������rΪ������
{//��һ����
	if (r != NULL) {
		if (ok(a, b, (c + a - 1) / 2, (b + d - 1) / 2) == 0)//�ڲ��ڵ�
		{
			t.InsertChild1(r->Child1, 'g');
			BuildTree(a, b, (c + a - 1) / 2, (b + d - 1) / 2, r->Child1);
		}
		else if (ok(a, b, (c + a - 1) / 2, (b + d - 1) / 2) == 1)//����
		{
			t.InsertChild1(r->Child1, 'w');
		}
		else if (ok(a, b, (c + a - 1) / 2, (b + d - 1) / 2) == 2)//����
		{
			t.InsertChild1(r->Child1, 'b');
		}

		//�ڶ�����
		if (ok(a,(b+d+1)/2,(c+a-1)/2,d) == 0)//�ڲ��ڵ�
		{
			t.InsertChild2(r->Child2, 'g');
			BuildTree(a, (b + d + 1) / 2, (c + a - 1) / 2, d, r->Child2);
		}
		else if (ok(a, (b + d + 1) / 2, (c + a - 1) / 2, d) == 1)//����
		{
			t.InsertChild2(r->Child2, 'w');
		}
		else if (ok(a, (b + d + 1) / 2, (c + a - 1) / 2, d) == 2)//����
		{
			t.InsertChild2(r->Child2, 'b');
		}
		//��������
		if (ok((a+c+1)/ 2, b , c,(b+d-1) / 2) == 0)//�ڲ��ڵ�
		{
			t.InsertChild3(r->Child3, 'g');
			BuildTree((a + c + 1) / 2, b, c, (b + d - 1) / 2, r->Child3);
		}
		else if (ok((a + c + 1) / 2, b, c, (b + d - 1) / 2) == 1)//����
		{
			t.InsertChild3(r->Child3, 'w');
		}
		else if (ok((a + c + 1) / 2, b, c, (b + d - 1) / 2) == 2)//����
		{
			t.InsertChild3(r->Child3, 'b');
		}
		//���ĺ���
		if (ok((a+c+1) / 2, (b+d+1) / 2, c, d) == 0)//�ڲ��ڵ�
		{
			t.InsertChild4(r->Child4, 'g');
			BuildTree((a + c + 1) / 2, (b + d + 1) / 2, c, d, r->Child4);
		}
		else if (ok((a + c + 1) / 2, (b + d + 1) / 2, c, d) == 1)//����
		{
			t.InsertChild4(r->Child4, 'w');
		}
		else if (ok((a + c + 1) / 2, (b + d + 1) / 2, c, d) == 2)//����
		{
			t.InsertChild4(r->Child4, 'b');
		}
	}
}


template<class ele>
void QuatreTree<ele>::begin() {
	if (ok(1, 1, n, n) == 0) {
		root = new QuatreTreeNode <ele>('g');
	}
	else if (ok(1,1,n,n) == 1)//����
	{
		root = new QuatreTreeNode <ele>('w');
	}
	else if (ok(1,1,n,n) == 2)//����
	{
		root = new QuatreTreeNode <ele>('b');
	}
	BuildTree(1,1,n,n,root);
}*/