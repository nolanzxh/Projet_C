#ifndef QUATRETREE_H
#define QUQTRETREE_H
#include<iostream>
#include<string>

using namespace std;

class NotesException {
public:
	NotesException(const string & message) :info(message) {}
	string getInfo() const { return info; }
private:
	string info;
};

template<class ele>
struct QuatreTreeNode//�Ĳ������
{
	ele data;
	QuatreTreeNode<ele> *Child1;//�ĸ�����ָ��
	QuatreTreeNode<ele> *Child2;
	QuatreTreeNode<ele> *Child3;
	QuatreTreeNode<ele> *Child4;

	QuatreTreeNode();
	QuatreTreeNode(const ele &d,
		QuatreTreeNode<ele> *Child1 = NULL ,
		QuatreTreeNode<ele> *Child2 = NULL , 
		QuatreTreeNode<ele> *Child3 = NULL , 
		QuatreTreeNode<ele> *Child4 = NULL);
};


template<class ele>
class QuatreTree
{
protected :
	QuatreTreeNode<ele>	*root;
	int n; //�������
	int arr[128][128];
	void PreOrder(QuatreTreeNode<ele> *r)const;
	int ok(int a, int b, int c,  int d)const;
public:

	QuatreTree();
	~QuatreTree();
	void begin();
	void PreOrder() const;//�������
	void InsertChild1(QuatreTreeNode<ele> *p, const ele& e);
	void InsertChild2(QuatreTreeNode<ele> *p, const ele& e);
	void InsertChild3(QuatreTreeNode<ele> *p, const ele& e);
	void InsertChild4(QuatreTreeNode<ele> *p, const ele& e);
	void SetN() { //�������
		int k;
		cout<<"entrer k(1<k<=7):"; cin >> k;
		if (k>=8 || k < 1) throw NotesException("valeur de k incorrecte");
		n = pow(2, k);
	}
	void SetArr();//����ͼ��
	void BuildTree(int a, int b, int c, int d,QuatreTreeNode<ele> *r);//�������Ͻǣ�a,b�����½ǣ�c,d����ͼ���Ӧ���Ĳ���
};


template <class ele>
QuatreTreeNode<ele>::QuatreTreeNode() {

	Child1 = Child2 = Child3 = Child4 = NULL;

}

template <class ele>
QuatreTreeNode<ele>::QuatreTreeNode(const ele &d,
	QuatreTreeNode<ele> *lChild1,
	QuatreTreeNode<ele> *lChild2,
	QuatreTreeNode<ele> *lChild3,
	QuatreTreeNode<ele> *lChild4) {

	data = d;
	Child1 = lChild1;
	Child2 = lChild2;
	Child3 = lChild3;
	Child4 = lChild4;
}


template<class ele>
void QuatreTree<ele>::InsertChild1(QuatreTreeNode<ele> *p, const ele& e) {//����p�ĵ�һ���ӣ�ֵΪe

	if (p == NULL)
		return;
	else {
		QuatreTreeNode<ele> *child = new QuatreTreeNode<ele>(e);
		if (p->Child1 != NULL)
			child->Child1 = p->Child1;
		p->Child1 = child;
		return;
	}

}

template<class ele>
void QuatreTree<ele>::InsertChild2(QuatreTreeNode<ele> *p, const ele& e) {

	if (p == NULL)
		return;
	else {
		QuatreTreeNode<ele> *child = new QuatreTreeNode<ele>(e);
		if (p->Child2 != NULL)
			child->Child2 = p->Child2;
		p->Child2 = child;
		return;
	}

}

template<class ele>
void QuatreTree<ele>::InsertChild3(QuatreTreeNode<ele> *p, const ele& e) {

	if (p == NULL)
		return;
	else {
		QuatreTreeNode<ele> *child = new QuatreTreeNode<ele>(e);
		if (p->Child3 != NULL)
			child->Child3 = p->Child3;
		p->Child3 = child;
		return;
	}

}

template<class ele>
void QuatreTree<ele>::InsertChild4(QuatreTreeNode<ele> *p, const ele& e) {

	if (p == NULL)
		return;
	else {
		QuatreTreeNode<ele> *child = new QuatreTreeNode<ele>(e);
		if (p->Child4 != NULL)
			child->Child4 = p->Child4;
		p->Child4 = child;
		return;
	}

}


template<class ele>
QuatreTree<ele>::~QuatreTree() {

	delete[]root;

}


template<class ele>
QuatreTree<ele>::QuatreTree() {

	n = 0;
	root = NULL;

}


template<class ele>
void QuatreTree<ele>::PreOrder() const {
	cout << "resultat:";
	PreOrder(root);

}

template<class ele>
void QuatreTree<ele>::PreOrder(QuatreTreeNode<ele> *r)const {
	if (r != NULL) {
		cout << r->data<<" ";
		PreOrder(r->Child1);
		PreOrder(r->Child2);
		PreOrder(r->Child3);
		PreOrder(r->Child4);
	}
}

template<class ele>
void QuatreTree<ele>::SetArr() {
	cout << "entrer le graphe:\n";
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= n; j++) {
			cin >> arr[i][j];
			if ((arr[i][j] != 1) && (arr[i][j] != 0))
				throw NotesException("information inserted incorrect");
		}
}

template<class ele>
int QuatreTree<ele>::ok(int a, int b, int c, int d) const {

	bool black = 0;
	bool white = 0;
	for (int i = a; i <= c; i++)
		for (int j = b; j <= d; j++)
		{
			if (arr[i][j] == 1) black = 1; //1�Ǻ�ɫ
			if (arr[i][j] == 0) white = 1;//0�ǰ�ɫ
		}
	if (white && black) return 0;//�к��а�
	else if (white && (!black)) return 1;//����
	else if ((!white) && black) return 2;//����
}


template<class ele>
void QuatreTree<ele>::BuildTree(int a, int b, int c, int d, QuatreTreeNode<ele> *t) //������rΪ������
{//�ڶ�����
	if (t != NULL) {
		if (ok(a, b, (c + a - 1) / 2, (b + d - 1) / 2) == 0)//�ڲ��ڵ�
		{
			InsertChild2(t, 'g');
			BuildTree(a, b, (c + a - 1) / 2, (b + d - 1) / 2, t->Child2);
		}
		else if (ok(a, b, (c + a - 1) / 2, (b + d - 1) / 2) == 1)//����
		{
			InsertChild2(t, 'w');
		}
		else if (ok(a, b, (c + a - 1) / 2, (b + d - 1) / 2) == 2)//����
		{
			InsertChild2(t, 'b');
		}

		//��һ����
		if (ok(a, (b + d + 1) / 2, (c + a - 1) / 2, d) == 0)//�ڲ��ڵ�
		{
			InsertChild1(t, 'g');
			BuildTree(a, (b + d + 1) / 2, (c + a - 1) / 2, d, t->Child1);
		}
		else if (ok(a, (b + d + 1) / 2, (c + a - 1) / 2, d) == 1)//����
		{
			InsertChild1(t, 'w');
		}
		else if (ok(a, (b + d + 1) / 2, (c + a - 1) / 2, d) == 2)//����
		{
			InsertChild1(t, 'b');
		}
		//��������
		if (ok((a + c + 1) / 2, b, c, (b + d - 1) / 2) == 0)//�ڲ��ڵ�
		{
			InsertChild3(t, 'g');
			BuildTree((a + c + 1) / 2, b, c, (b + d - 1) / 2, t->Child3);
		}
		else if (ok((a + c + 1) / 2, b, c, (b + d - 1) / 2) == 1)//����
		{
			InsertChild3(t, 'w');
		}
		else if (ok((a + c + 1) / 2, b, c, (b + d - 1) / 2) == 2)//����
		{
			InsertChild3(t, 'b');
		}
		//���ĺ���
		if (ok((a + c + 1) / 2, (b + d + 1) / 2, c, d) == 0)//�ڲ��ڵ�
		{
			InsertChild4(t, 'g');
			BuildTree((a + c + 1) / 2, (b + d + 1) / 2, c, d, t->Child4);
		}
		else if (ok((a + c + 1) / 2, (b + d + 1) / 2, c, d) == 1)//����
		{
			InsertChild4(t, 'w');
		}
		else if (ok((a + c + 1) / 2, (b + d + 1) / 2, c, d) == 2)//����
		{
			InsertChild4(t, 'b');
		}
	}
}


template<class ele>
void QuatreTree<ele>::begin() {
	if (ok(1, 1, n, n) == 0) {
		root = new QuatreTreeNode <ele>('g');
	}
	else if (ok(1, 1, n, n) == 1)//����
	{
		root = new QuatreTreeNode <ele>('w');
	}
	else if (ok(1, 1, n, n) == 2)//����
	{
		root = new QuatreTreeNode <ele>('b');
	}
	BuildTree(1, 1, n, n, root);
}
#endif