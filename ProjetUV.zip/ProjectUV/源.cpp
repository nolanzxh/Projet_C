#include<iostream>
#include"QuatreTree.h"

using namespace std;


int main() {
	QuatreTree<char> t;
	try {
	t.SetN();
	t.SetArr();
	t.begin();
	t.PreOrder();
	}
	catch(NotesException &e){
		cout << e.getInfo() << endl;
	}
	system("pause");
	return 0;
}